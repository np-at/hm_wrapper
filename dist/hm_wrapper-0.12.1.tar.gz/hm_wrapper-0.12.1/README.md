# hm_wrapper
built on top of https://github.com/SLiX69/Sonarr-API-Python-Wrapper, provides a python(3) wrapper for interacting with Sonarr and Radarr APIs

# WIP
