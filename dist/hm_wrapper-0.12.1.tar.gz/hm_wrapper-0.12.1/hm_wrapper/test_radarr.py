from unittest import TestCase


class TestRadarr(TestCase):
    def test_get_history(self):
        self.fail()
